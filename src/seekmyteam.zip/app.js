var AWS = require('aws-sdk');
var express = require('express');
var bodyParser = require('body-parser');
var controllers = require('./controllers');

AWS.config.region = process.env.REGION

var sns = new AWS.SNS();
var ddb = new AWS.DynamoDB();

var snsTopic =  process.env.NEW_SIGNUP_TOPIC;
var app = express();

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(bodyParser.urlencoded({extended:false}));

app.use('/', controllers);

var port = process.env.PORT || 3000;

var server = app.listen(port, function () {
    console.log('Server running at http://127.0.0.1:' + port + '/');
});

module.exports.database = ddb;




